num = int(input("Indique um número: "))

if (num%2 == 0):
    print("O número",num,"é par")

else: print("O número",num,"é ímpar")