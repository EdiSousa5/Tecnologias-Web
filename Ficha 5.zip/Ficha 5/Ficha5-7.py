import random

def generatePassword(frase):
    comp = len(frase)
    resultado = ""

    for i in range(comp):
        n = random.randint(1,9)
        if((i+1)%2!=0): resultado += str(n)

        else: resultado += frase[i]

    return resultado
       

frase = str(input("Escreva uma frase: "))


print("\n",generatePassword(frase))