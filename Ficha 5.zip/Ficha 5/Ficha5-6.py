def standardName(frase):
    resultado = ""
    ultimo = ""
    letra = 0
    count = 0
    comp = len(frase)

    for i in range(comp):
        if(frase[i] == " "): 
            count = 1
            letra = 0

        elif(count == 0): resultado += frase[i]

        elif(count == 1):
            letra += 1
            if(letra == 1): resultado += " " + frase[i] + "."


    resultado = resultado[:len(resultado)-2]

    for k in range(comp-1,-1,-1):
        if(frase[k] == " "): break

        else: ultimo += frase[k]

    resultado += ultimo[::-1]
    return resultado

frase = str(input("Escreva uma frase: "))

print("\n",standardName(frase))