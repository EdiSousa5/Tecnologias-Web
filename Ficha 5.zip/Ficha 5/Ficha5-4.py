def removeSpaces(frase):
    resultado = ""
    count = 0
    for i in range(len(frase)):
        if(frase[i] != " "): 
            resultado += frase[i]
            count = 0

        else:
            count += 1
            if(count == 1): resultado += frase[i]

    return resultado

frase = str(input("Escreva uma frase: "))

print("\n", removeSpaces(frase))