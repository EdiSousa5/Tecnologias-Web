frase = str(input("Escreva uma frase: "))
pesquisa = str(input("Escreva uma palavra para pesquisar: "))

print(frase.count(pesquisa))