def shortName(frase):
    primeiro = ""
    ultimo = ""
    comp = len(frase)

    for i in range(comp):
        if(frase[i] == " "): break

        else: primeiro += frase[i]

    for k in range(comp-1,-1,-1):
        if(frase[k] == " "): break

        else: ultimo += frase[k]

    if(primeiro == ultimo[::-1]): resultado = primeiro
        
    else: resultado = primeiro + " " + ultimo[::-1]

    return resultado

frase = str(input("Escreva uma frase: "))

print(shortName(frase))