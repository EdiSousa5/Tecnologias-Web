frase = str(input("Escreva uma frase: "))

print("Frase inversa: ", frase[::-1])