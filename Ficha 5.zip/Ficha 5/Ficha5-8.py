def reverseWords(frase):
    resultado = ""
    palavra = ""
    comp = len(frase)
    frase = frase[::-1]

    for i in range(comp):
        palavra += frase[i]

        if(frase[i] == " "):
            resultado += palavra[::-1]
            palavra = ""

    resultado += " " + palavra[::-1]

    return resultado[1:]

frase = str(input("Escreva uma frase: "))

print("Resultado:",reverseWords(frase))