frase = str(input("Escreva uma frase: "))

vogais = 0
VogaisLista = ["a","e","i","o","u"]

for i in range(len(frase)):
    if frase[i].lower() in VogaisLista:
        vogais += 1

print("Número de caracteres: ", len(frase))
print("Número de vogais: ", vogais)
print("Número de espaços: ", frase.count(" "))