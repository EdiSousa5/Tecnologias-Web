def capicua(frase):
    inverso = frase[::-1]
    if(frase == inverso): return True

    else: return False

frase = str(input("Escreva uma frase: "))
frase = frase.lower()

if(capicua(frase) == True): print("\nO texto é capicua")

else: print("\nO texto não é capicua")