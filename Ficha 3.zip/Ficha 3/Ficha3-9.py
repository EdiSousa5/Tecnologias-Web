num = int(input("Indique um número: "))
soma = 0

for i in range(1,num):
    if(num % i == 0): soma += i

if(soma == num): print(num, "é um número perfeito")

else: print(num, "não é um número perfeito")