num = int(input("Indique o número de termos a imprimir: "))

num1 = 0
num2 = 1

lista = "0, 1"

for i in range(2,num):
    atual = num1+num2

    lista += f" , {atual}"
    
    num1 = num2
    num2 = atual

print(f"Primeiros ", num, "termos da sequência:", lista)