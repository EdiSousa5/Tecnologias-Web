import random

num = random.randint(1,50)
vidas = 10

print("Tente adivinhar um número entre 1-50!\nBoa sorte!!")

while(vidas!=0):

    resposta = int(input("\nQual acha que é o número aleatório: "))
    if (resposta == num):
        print("\nParabéns!! Acertas-te qual era o número!!\n")
        exit()
    
    elif (resposta < num):
        print("\nA respota é MAIOR que este número!!")
        vidas -= 1
        print("Vidas:", vidas)

    elif (resposta > num):
        print("\nA respota é MENOR que este número!!")
        vidas -= 1
        print("Vidas:", vidas)

print("\nAs suas vidas acabaram..")
print("\nO número era:", num)