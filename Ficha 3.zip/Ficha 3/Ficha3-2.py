maior = -999999999999999999999999999999
media = 0

quant = int(input("Indique a quantidade de números que deseja ler: "))

for i in range(quant):
    num = int(input("Indique um número: "))
    media += num
    if (num > maior): maior = num
print("A media é", (media/quant))
print("O maior número é", maior)