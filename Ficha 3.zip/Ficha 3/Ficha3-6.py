import random

ano = random.randint(1900,2020)
resposta = "S"

while(resposta=="S" or resposta=="s"):

    print("\nAno generado:", ano, "\n")

    if(ano%400 == 0): print("É um ano bissexto")

    elif(ano%4==0 and ano%100!=0): print("É um ano bissexto")

    else: print("É um ano não bissexto")

    resposta = str(input("\nQueres experimentar novamente(S/N): "))

    if( resposta == "S" or resposta == "s"): ano = random.randint(1900,2020)