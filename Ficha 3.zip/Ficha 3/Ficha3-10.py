n = 0
resultado = ""

while(n < 1 or n > 50):
    n = int(input("Indique um número entre 1-50: "))
    if(n < 1 or n > 50): print("Indique o valor devidamente..\n")

num = n

while(n > 0):
    resultado = str(n%2) + resultado
    n = int(n/2)

print(num, "em binário:", resultado)