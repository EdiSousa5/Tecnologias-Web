quant = int(input("Quantidade de números: "))
maior1 = -9999999
maior2 = -9999999

for i in range(quant):
    num = int(input("Indique um número: "))

    if(num > maior1): 
        maior2 = maior1
        maior1 = num

    elif(num > maior2): maior2 =num

print("resultao" ,maior2)
