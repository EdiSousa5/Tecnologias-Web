num = int(input("Indique a quantidade de números que deseja ler: "))
fato = 1

for i in range(num):
    fato *= num
    num -= 1

print("O fatorial de", num, "é", fato)