num = int(input("Indique um número: "))
count = 0

for i in range(1,num+1):
    if(num%i == 0): count += 1

if(count == 2): print(num, "é um numero primo")

else: print(num, "não é um numero primo")