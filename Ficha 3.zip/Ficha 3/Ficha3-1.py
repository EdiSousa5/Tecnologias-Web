maior = -999999999999999999999999999999
media = 0

for i in range(10):
    num = int(input("Indique um número: "))
    media += num
    if (num > maior): maior = num
print("A media é", (media/10))
print("O maior número é", maior)